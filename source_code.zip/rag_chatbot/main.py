import gradio as gr
from src.ui.gradio_app import demo
from fastapi import FastAPI
from src.api.chat_router import router

app = FastAPI()
app.include_router(router)
app = gr.mount_gradio_app(app, demo, path="/")

demo.launch(share=True, inbrowser=True)