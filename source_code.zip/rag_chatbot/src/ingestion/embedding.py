from langchain_openai import OpenAIEmbeddings
from src.core.config import config

embeddings = OpenAIEmbeddings(
    model=config.EMBEDDING_MODEL,
    api_key=config.OPENAI_API_KEY
)