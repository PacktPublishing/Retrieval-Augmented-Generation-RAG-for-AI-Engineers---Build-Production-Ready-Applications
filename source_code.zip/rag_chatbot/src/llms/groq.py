from langchain_groq import ChatGroq
from src.core.config import config


groq_llm = ChatGroq(
    model=config.GROQ_MODEL_NAME,
    api_key=config.GROQ_API_KEY
)
