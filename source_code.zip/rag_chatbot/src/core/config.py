import os
from dotenv import load_dotenv

load_dotenv()

class Config: 
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    GROQ_MODEL_NAME = "openai/gpt-oss-120b"
    
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    OPENAI_MODEL = "gpt-5.4-mini"
    
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

    # Embeddings
    EMBEDDING_MODEL = "text-embedding-3-small"
    
    # Document loading
    DATA_DIR = "data/"
    DATA_GLOB = "**/*.txt"

    # Text splitting
    CHUNK_SIZE = 1000
    CHUNK_OVERLAP = 200
    
    # Vector store
    CHROMA_PERSIST_DIRECTORY = "data/chroma_db"
    
    # Retrieval
    SEARCH_TYPE = "similarity"
    RETRIEVER_K = 3
    
config = Config()    