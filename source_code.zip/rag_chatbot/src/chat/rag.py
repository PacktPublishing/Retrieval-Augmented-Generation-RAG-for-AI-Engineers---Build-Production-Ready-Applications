from src.retrieval.retriever import retriever
from src.prompts.main_prompt import prompt_template
from src.llms.openai import openai_llm
from src.llms.groq import groq_llm

def ask_question(question: str) -> str:
        
    retrieved_docs = retriever.invoke(question)
    context = "\n\n".join(document.page_content for document in retrieved_docs)


    formatted_prompt = prompt_template.format(
        context=context,
        question=question
    )

    response = groq_llm.invoke(formatted_prompt)
    return response.content