from src.ingestion.vectore_store import vector_store
from src.core.config import config

question = input("Enter your question")

retriever = vector_store.as_retriever(search_type=config.SEARCH_TYPE, search_kwargs={"k": config.RETRIEVER_K})
retrieved_docs = retriever.invoke(question)
