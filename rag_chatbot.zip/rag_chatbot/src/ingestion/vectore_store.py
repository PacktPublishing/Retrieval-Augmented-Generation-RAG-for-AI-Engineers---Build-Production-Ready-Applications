from langchain_chroma import Chroma

from src.ingestion.splitter import chunks
from src.ingestion.embedding import embeddings
from src.core.config import config

def _build_vector_store() -> Chroma:
    store = Chroma(
        collection_name=config.CHROMA_COLLECTION_NAME,
        embedding_function=embeddings,
        persist_directory=config.CHROMA_PERSIST_DIRECTORY
    )
    
    if store._collection.count() == len(chunks):
        return store
    
    if store._collection.count() > 0:
        store.delete_collection()
        
    return Chroma.from_documents(
        collection_name=config.CHROMA_COLLECTION_NAME,
        documents=chunks, 
        embedding=embeddings,
        persist_directory=config.CHROMA_PERSIST_DIRECTORY
    )
        

vector_store = _build_vector_store()