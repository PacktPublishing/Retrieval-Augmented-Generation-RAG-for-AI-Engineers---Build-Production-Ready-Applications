from src.retrieval.retriever import retriever
from src.prompts.main_prompt import prompt_template
from src.llms.openai import openai_llm
from src.llms.groq import groq_llm


def fetch_context(question: str, filter: dict | None = None) -> list:
    """
    Retrieve documents for a question (used by the app and by evaluation).

    filter is optional metadata, e.g. {"source_file": "faq.txt"}.
    Evaluation and existing callers keep working with fetch_context(question).
    """
    return retriever.invoke(question, filter=filter)

def _format_context(documents: list) -> str:
    blocks = []
    for i, document in enumerate(documents, start=1):
        blocks.append(f"[Excerpt {i}]\n{document.page_content}")
        
    return "\n\n".join(blocks)    

def answer_question(question: str) -> tuple[str, list]:
    """
    Run the full RAG pipeline.
    Returns the generated answer and the retrieved documents.
    """
    retrieved_docs = fetch_context(question)
    context = _format_context(retrieved_docs)

    formatted_prompt = prompt_template.format(
        context=context,
        question=question,
    )

    response = groq_llm.invoke(formatted_prompt)
    return response.content, retrieved_docs


def ask_question(question: str) -> str:
    """Return only the answer string (used by the UI and API)."""
    answer, _ = answer_question(question)
    return answer
