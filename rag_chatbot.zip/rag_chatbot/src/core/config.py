import os
from dotenv import load_dotenv

load_dotenv()

class Config: 
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    GROQ_MODEL_NAME = "openai/gpt-oss-120b"
    
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    OPENAI_MODEL = "gpt-5.4-mini"
    
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

    # Embeddings
    EMBEDDING_MODEL = "text-embedding-3-small"
    
    # Document loading
    DATA_DIR = "data/"
    DATA_GLOB = "**/*.txt"

    # Text splitting
    CHUNK_SIZE = 700
    CHUNK_OVERLAP = 120
    
    # Vector store
    CHROMA_COLLECTION_NAME="ccc_docs"
    CHROMA_PERSIST_DIRECTORY = "data/chroma_db"
    
    # Retrieval
    SEARCH_TYPE = "hybrid"
    
    BM25_K = 20
    DENSE_K = 20
    
    RRF_K = 60
    FUSION_LIMIT= 40
    
    RERANK_TOP_K=5
    RERANK_ENABLED = True
    RERANK_MODEL = "ms-marco-MiniLM-L-12-v2"
    RERANK_CACHE_DIR = "data/flashrank_cache"
    
config = Config()    