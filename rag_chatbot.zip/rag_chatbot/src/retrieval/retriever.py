"""
Hybrid retrieval pipeline:

    Query
      ├─ Dense (Chroma) - Semantic Search ( Meaning ) → top DENSE_K
      └─ BM25 (keywords) - Keyword Search → top BM25_K
              ↓
         RRF fusion  (rank-based; score scales differ)
              ↓
         Cross-encoder rerank  (query + doc scored together)
              ↓
         top RERANK_TOP_K  → LLM context
"""

import re
from functools import lru_cache
from typing import Any
from langchain_community.retrievers import BM25Retriever
from langchain_core.documents import Document

from src.ingestion.vectore_store import vector_store
from src.core.config import config
from src.ingestion.splitter import chunks

Filter = dict[str, Any] | None

def _bm25_preprocess(text: str) -> list[str]:
    # "Minimum WARRANTY Period" -> ["minimum", "warranty", "period"]
    return re.findall(r"[a-z0-9]+", text.lower())

bm25_retriever = BM25Retriever.from_documents(
    chunks,
    preprocess_func=_bm25_preprocess
)

bm25_retriever.k = config.BM25_K

@lru_cache(maxsize=1)
def _get_ranker():
    from flashrank import Ranker
    
    return Ranker(model_name=config.RERANK_MODEL, cache_dir=config.RERANK_CACHE_DIR)

def _dense_search(query: str, metadata_filter: Filter = None) -> list[Document]:
    kwargs: dict[str, Any] = {"k" : config.DENSE_K } 
    
    if metadata_filter:
        kwargs["filter"] = metadata_filter
        
    return vector_store.similarity_search(query, **kwargs)      

def _bm25_search(query: str, metadata_filter: Filter = None) -> list[Document]:
    
    if not metadata_filter:
        return bm25_retriever.invoke(query)
    
    matching = [
        chunk
        for chunk in chunks
        if all(
            chunk.metadata.get(key) == value for key, value in metadata_filter.items()
        )
    ]
    
    if not matching:
        return []
    
    scoped = BM25Retriever.from_documents(
        matching, preprocess_func=_bm25_preprocess
    )
    
    scoped.k = min(config.BM25_K, len(matching))
    
    return scoped.invoke(query)


def reciprocal_rank_fusion(
    result_lists: list[list[Document]],
    k: int = 60,
    limit: int | None = None
) -> list[Document]:
    
    scores: dict[str, float] = {}
    docs_by_key: dict[str, Document] = {}
    
    for docs in result_lists:
        seen: set[str] = set[str]()
        rank = 0
        
        for doc in docs:
            key = doc.page_content
            
            if key in seen:
                continue
            
            seen.add(key)
            rank += 1
            
            docs_by_key.setdefault(key, doc)
            
            # for RRF score
            scores[key] = scores.get(key, 0.0) + 1.0 / (k + rank)
        
    ranked = sorted(scores, key=scores.get, reverse=True)
    return [docs_by_key[key] for key in ranked[:limit]]    

def _rerank(query: str, docs: list[Document], top_k: int) -> list[Document]:
    """
    Re-score candidates with a cross-encoder, which reads (query, document)
    together instead of embedding them separately — slower, but better ranking.
    """
    if not docs or not config.RERANK_ENABLED:
        return docs[:top_k]
    
    from flashrank import RerankRequest

    passages = [
        {"id": i, "text": doc.page_content}
        for i, doc in enumerate(docs)
    ]
    
    results = _get_ranker().rerank(RerankRequest(query=query, passages=passages))

    return [docs[item["id"]] for item in results[:top_k]]
    
class HybridRetriever:
    """
    Dense + BM25 → RRF → optional cross-encoder rerank.

        retriever.invoke("what is the warranty?")
        retriever.invoke("warranty", filter={"source_file": "warranty_service.txt"})
    """
    
    def invoke(self, query: str, filter: Filter = None) -> list[Document]:
        candidates = reciprocal_rank_fusion(
            [_dense_search(query, filter), _bm25_search(query, filter)],
            k=config.RRF_K,
            limit=config.FUSION_LIMIT
        )
        
        return _rerank(query, candidates, config.RERANK_TOP_K)
       
retriever = HybridRetriever()      